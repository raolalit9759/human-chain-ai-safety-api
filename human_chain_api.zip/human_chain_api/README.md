# HumanChain AI Safety Incident Log API

A simple Flask-based RESTful API to log and manage hypothetical AI safety incidents.

---

## 🚀 Tech Stack

- **Language:** Python
- **Framework:** Flask
- **Database:** MongoDB
- **ODM:** Flask-PyMongo
- **Environment Config:** python-dotenv

---

## 📁 Project Structure

human_chain_api/ ├── app.py # Main Flask application ├── seed.py # Script to insert sample incidents ├── .env # Environment variables (contains MongoDB URI) ├── requirements.txt # Required Python packages └── README.md # Project instructions
